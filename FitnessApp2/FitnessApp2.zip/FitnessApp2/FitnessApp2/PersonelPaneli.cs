﻿using Business.Abstract;
using Entities.Concrete;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FitnessApp2
{
    public partial class PersonelPaneli : Form
    {
        private readonly IMusteriService _musteriService;
        private readonly IPaketService _paketService;
        private readonly IEgitmenService _egitmenService;
        private readonly IYoneticiService _yoneticiService;
        private readonly IPersonelService _girispersonelService;
        private readonly IServiceProvider _serviceProvider;


        private int selectedPaketId;
        private int selectedEgitmenId;
        private int selectedPaketFiyati;
        private int selectedOzelDersFiyati;

        public PersonelPaneli(IMusteriService musteriService, IPaketService paketService, IEgitmenService egitmenService)
        {
            _musteriService = musteriService;
            _paketService = paketService;
            _egitmenService = egitmenService;
            InitializeComponent();
            LoadMusteriler();
            LoadPaketler();
            LoadEgitmenler();

            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView3.CellClick += dataGridView3_CellClick;


        }
        private void LoadMusteriler()
        {
            dataGridView2.DataSource = _musteriService.GetAll();
        }
        private void LoadEgitmenler()
        {
            dataGridView3.DataSource = _egitmenService.GetAll();
        }
        private void LoadPaketler()
        {
            dataGridView1.DataSource = _paketService.GetAll();
        }
        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void PersonelPaneli_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) //musteri ekleme 
        {
            var musteri = new Musteri
            {
                Ad = textBox1.Text,
                Soyad = textBox3.Text,
                Eposta = textBox4.Text,
                TelefonNumarasi = textBox5.Text,
                PaketlerId = selectedPaketId,
                EgitmenId = selectedEgitmenId,
                Odeme = selectedPaketFiyati + selectedOzelDersFiyati,
                KayitTarihi = dateTimePicker1.Value

            };

            _musteriService.Add(musteri);
            LoadMusteriler();
        }

        private void button4_Click(object sender, EventArgs e)//paket secimi butonu
        {
            LoadPaketler();
        }

        private void button5_Click(object sender, EventArgs e) //egitmen secimi butonu 
        {
            LoadEgitmenler();
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)//egitmen
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView3.Rows[e.RowIndex];
                selectedEgitmenId = Convert.ToInt32(row.Cells["Id"].Value);
                textBox2.Text = selectedEgitmenId.ToString();
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)//paket
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                selectedPaketId = Convert.ToInt32(row.Cells["Id"].Value);
                selectedPaketFiyati = Convert.ToInt32(row.Cells["ToplamPaketFiyati"].Value);
                selectedOzelDersFiyati = Convert.ToInt32(row.Cells["OzelDersFiyati"].Value);


                label10.Text = (selectedPaketFiyati + selectedOzelDersFiyati).ToString();
                textBox6.Text = selectedPaketId.ToString();
            }

        }

        private void button2_Click(object sender, EventArgs e)//musterisilme
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {
                var musteri = (Musteri)dataGridView2.SelectedRows[0].DataBoundItem;
                _musteriService.Delete(musteri);
                LoadMusteriler();
            }


        }

        private void button3_Click(object sender, EventArgs e)//musteri guncelleme
        {

            if (dataGridView2.SelectedRows.Count > 0)
            {
                var musteri = (Musteri)dataGridView2.SelectedRows[0].DataBoundItem;

                musteri.Ad = textBox1.Text;
                musteri.Soyad = textBox3.Text;
                musteri.TelefonNumarasi = textBox4.Text;
                musteri.Eposta = textBox5.Text;
                musteri.EgitmenId = Convert.ToInt32(textBox2.Text);
                musteri.PaketlerId = Convert.ToInt32(textBox6.Text);
                musteri.Odeme = Convert.ToInt32(label10.Text);
                musteri.KayitTarihi = dateTimePicker1.Value;
                _musteriService.Update(musteri);
                LoadMusteriler();
            }

        }

        private void dataGridView2_SelectionChanged(object sender, EventArgs e)
        {

            if (dataGridView2.SelectedRows.Count > 0)
            {
                var musteri = (Musteri)dataGridView2.SelectedRows[0].DataBoundItem;

                textBox1.Text = musteri.Ad;
                textBox3.Text = musteri.Soyad;
                textBox4.Text = musteri.Eposta;
                textBox5.Text = musteri.TelefonNumarasi;

                textBox2.Text = Convert.ToString(musteri.EgitmenId);
                textBox6.Text = Convert.ToString(musteri.PaketlerId);

            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {

            if (dataGridView2.SelectedRows.Count > 0)
            {
                var paket = (Paket)dataGridView2.SelectedRows[0].DataBoundItem;


                textBox2.Text = Convert.ToString(paket.Id);


            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var yoneticiGirisiYap = new YoneticiGirisiYap(_yoneticiService, _girispersonelService, _serviceProvider);
            yoneticiGirisiYap.Show();
            this.Close();
        }
    }
    /*private void button3_Click(object sender, EventArgs e)
{
if (dataGridView2.CurrentRow != null)
{
int musteriId = Convert.ToInt32(dataGridView2.CurrentRow.Cells["Id"].Value);
var musteri = _musteriService.GetById(musteriId); // Veritabanından mevcut müşteri verisini çekin
musteri.Ad = textBox1.Text;
musteri.Soyad = textBox3.Text;
musteri.Eposta = textBox4.Text;
musteri.TelefonNumarasi = textBox5.Text;
musteri.PaketlerId = selectedPaketId;
musteri.EgitmenId = selectedEgitmenId;
musteri.Odeme = selectedPaketFiyati;

_musteriService.Update(musteri);
LoadMusteriler();
}
}
*/
}

