﻿namespace FitnessApp2
{
    partial class PersonelPaneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label6 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label5 = new Label();
            label4 = new Label();
            textBox6 = new TextBox();
            textBox2 = new TextBox();
            dataGridView3 = new DataGridView();
            button5 = new Button();
            button4 = new Button();
            dataGridView1 = new DataGridView();
            dataGridView2 = new DataGridView();
            label11 = new Label();
            label10 = new Label();
            label8 = new Label();
            textBox5 = new TextBox();
            textBox3 = new TextBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            textBox4 = new TextBox();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            textBox1 = new TextBox();
            button6 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.FromArgb(255, 192, 192);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(dateTimePicker1);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(dataGridView3);
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(button4);
            groupBox1.Controls.Add(dataGridView1);
            groupBox1.Controls.Add(dataGridView2);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(1136, 657);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "MUSTERİ EKLE";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(3, 259);
            label6.Name = "label6";
            label6.Size = new Size(40, 20);
            label6.TabIndex = 55;
            label6.Text = "Tarih";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(76, 259);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 54;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(-1, 223);
            label5.Name = "label5";
            label5.Size = new Size(57, 20);
            label5.TabIndex = 53;
            label5.Text = "PaketId";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(0, 193);
            label4.Name = "label4";
            label4.Size = new Size(77, 20);
            label4.TabIndex = 52;
            label4.Text = "EgitmenId";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(76, 223);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 51;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(76, 190);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 50;
            // 
            // dataGridView3
            // 
            dataGridView3.BackgroundColor = SystemColors.ActiveCaptionText;
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(684, 56);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.Size = new Size(403, 166);
            dataGridView3.TabIndex = 49;
            dataGridView3.CellClick += dataGridView3_CellClick;
            // 
            // button5
            // 
            button5.Location = new Point(813, 13);
            button5.Name = "button5";
            button5.Size = new Size(133, 37);
            button5.TabIndex = 48;
            button5.Text = "EĞİTMEN SEÇİMİ";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.Location = new Point(363, 15);
            button4.Name = "button4";
            button4.Size = new Size(133, 37);
            button4.TabIndex = 47;
            button4.Text = "PAKET SEÇİMİ";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = SystemColors.ActiveCaptionText;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(235, 58);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(414, 166);
            dataGridView1.TabIndex = 41;
            dataGridView1.CellClick += dataGridView1_CellClick;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(41, 371);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(1046, 202);
            dataGridView2.TabIndex = 45;
            dataGridView2.SelectionChanged += dataGridView2_SelectionChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(7, 124);
            label11.Name = "label11";
            label11.Size = new Size(54, 20);
            label11.TabIndex = 40;
            label11.Text = "Eposta";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(103, 289);
            label10.Name = "label10";
            label10.RightToLeft = RightToLeft.Yes;
            label10.Size = new Size(25, 20);
            label10.TabIndex = 39;
            label10.Text = "00";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(-1, 289);
            label8.Name = "label8";
            label8.RightToLeft = RightToLeft.Yes;
            label8.Size = new Size(98, 20);
            label8.TabIndex = 34;
            label8.Text = "Toplam Ücret";
            label8.Click += label8_Click;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(76, 157);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 29;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(76, 86);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 27;
            // 
            // button3
            // 
            button3.Location = new Point(729, 289);
            button3.Name = "button3";
            button3.Size = new Size(143, 54);
            button3.TabIndex = 19;
            button3.Text = "GÜNCELLE";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.Location = new Point(456, 289);
            button2.Name = "button2";
            button2.Size = new Size(143, 54);
            button2.TabIndex = 18;
            button2.Text = "SİL";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Location = new Point(196, 289);
            button1.Name = "button1";
            button1.Size = new Size(143, 54);
            button1.TabIndex = 16;
            button1.Text = "EKLE";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(76, 121);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 27);
            textBox4.TabIndex = 28;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(7, 88);
            label2.Name = "label2";
            label2.Size = new Size(53, 20);
            label2.TabIndex = 21;
            label2.Text = "Soyad:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(23, 56);
            label1.Name = "label1";
            label1.Size = new Size(31, 20);
            label1.TabIndex = 17;
            label1.Text = "Ad:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(-1, 157);
            label3.Name = "label3";
            label3.Size = new Size(61, 20);
            label3.TabIndex = 24;
            label3.Text = "Telefon:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(76, 53);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 22;
            // 
            // button6
            // 
            button6.Location = new Point(1154, 17);
            button6.Name = "button6";
            button6.Size = new Size(116, 57);
            button6.TabIndex = 1;
            button6.Text = "GERİ";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // PersonelPaneli
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(1274, 681);
            Controls.Add(button6);
            Controls.Add(groupBox1);
            Name = "PersonelPaneli";
            Text = "PersonelPaneli";
            Load += PersonelPaneli_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox5;
        private TextBox textBox3;
        private Button button3;
        private Button button2;
        private Button button1;
        private TextBox textBox4;
        private Label label2;
        private Label label1;
        private Label label3;
        private TextBox textBox1;
        private Label label8;
        private DataGridView dataGridView1;
        private Label label11;
        private Label label10;
        private DataGridView dataGridView2;
        private DataGridView dataGridView3;
        private Button button5;
        private Button button4;
        private Label label5;
        private Label label4;
        private TextBox textBox6;
        private TextBox textBox2;
        private Label label6;
        private DateTimePicker dateTimePicker1;
        private Button button6;
    }
}