﻿namespace FitnessApp2
{
    partial class Muhasebe
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            dataGridView1 = new DataGridView();
            label7 = new Label();
            button1 = new Button();
            button3 = new Button();
            label9 = new Label();
            comboBox3 = new ComboBox();
            label11 = new Label();
            label12 = new Label();
            textBox1 = new TextBox();
            label13 = new Label();
            textBox2 = new TextBox();
            label14 = new Label();
            dateTimePicker1 = new DateTimePicker();
            button5 = new Button();
            label15 = new Label();
            dataGridView3 = new DataGridView();
            dateTimePicker2 = new DateTimePicker();
            button6 = new Button();
            dateTimePicker3 = new DateTimePicker();
            dataGridView4 = new DataGridView();
            dataGridView5 = new DataGridView();
            label16 = new Label();
            label17 = new Label();
            label18 = new Label();
            button7 = new Button();
            button8 = new Button();
            label19 = new Label();
            label20 = new Label();
            button9 = new Button();
            button10 = new Button();
            label21 = new Label();
            button2 = new Button();
            label1 = new Label();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label3.Location = new Point(610, 89);
            label3.Name = "label3";
            label3.Size = new Size(193, 38);
            label3.TabIndex = 2;
            label3.Text = "Gider Oluştur";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(1059, 77);
            label4.Name = "label4";
            label4.Size = new Size(207, 38);
            label4.TabIndex = 3;
            label4.Text = "Maaş Giderleri";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label5.Location = new Point(630, 19);
            label5.Name = "label5";
            label5.Size = new Size(184, 46);
            label5.TabIndex = 4;
            label5.Text = "Muhasebe";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label6.Location = new Point(175, 77);
            label6.Name = "label6";
            label6.Size = new Size(113, 38);
            label6.TabIndex = 5;
            label6.Text = "Gelirler";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(16, 127);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(443, 333);
            dataGridView1.TabIndex = 6;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label7.Location = new Point(186, 479);
            label7.Name = "label7";
            label7.Size = new Size(69, 28);
            label7.TabIndex = 9;
            label7.Text = "listele";
            // 
            // button1
            // 
            button1.Location = new Point(170, 544);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 10;
            button1.Text = "listele";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button3
            // 
            button3.Location = new Point(123, 579);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 14;
            button3.Text = "Topla";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label9.Location = new Point(239, 576);
            label9.Name = "label9";
            label9.Size = new Size(36, 28);
            label9.TabIndex = 15;
            label9.Text = "00";
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "Satın Alma", "Su", "Elektrik", "Vergi" });
            comboBox3.Location = new Point(743, 147);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(151, 28);
            comboBox3.TabIndex = 21;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label11.Location = new Point(588, 147);
            label11.Name = "label11";
            label11.Size = new Size(112, 28);
            label11.TabIndex = 22;
            label11.Text = "Gider Türü";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label12.Location = new Point(588, 192);
            label12.Name = "label12";
            label12.Size = new Size(114, 28);
            label12.TabIndex = 23;
            label12.Text = "Açıklaması";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(743, 193);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 24;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label13.Location = new Point(588, 235);
            label13.Name = "label13";
            label13.Size = new Size(58, 28);
            label13.TabIndex = 25;
            label13.Text = "Fiyat";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(743, 239);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 26;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label14.Location = new Point(588, 281);
            label14.Name = "label14";
            label14.Size = new Size(59, 28);
            label14.TabIndex = 27;
            label14.Text = "Tarih";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(743, 281);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(250, 27);
            dateTimePicker1.TabIndex = 29;
            dateTimePicker1.UseWaitCursor = true;
            dateTimePicker1.Value = new DateTime(2024, 5, 30, 0, 0, 0, 0);
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // button5
            // 
            button5.Location = new Point(588, 332);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 30;
            button5.Text = "Ekle";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label15.Location = new Point(617, 405);
            label15.Name = "label15";
            label15.Size = new Size(186, 38);
            label15.TabIndex = 31;
            label15.Text = "Giderleri Gör";
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(494, 461);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.Size = new Size(452, 333);
            dataGridView3.TabIndex = 32;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Location = new Point(494, 800);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(250, 27);
            dateTimePicker2.TabIndex = 33;
            // 
            // button6
            // 
            button6.Location = new Point(563, 833);
            button6.Name = "button6";
            button6.Size = new Size(94, 29);
            button6.TabIndex = 34;
            button6.Text = "Listele";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // dateTimePicker3
            // 
            dateTimePicker3.Font = new Font("Segoe UI", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 162);
            dateTimePicker3.Location = new Point(135, 512);
            dateTimePicker3.Name = "dateTimePicker3";
            dateTimePicker3.Size = new Size(197, 25);
            dateTimePicker3.TabIndex = 35;
            dateTimePicker3.ValueChanged += dateTimePicker3_ValueChanged;
            // 
            // dataGridView4
            // 
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Location = new Point(999, 174);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.RowHeadersWidth = 51;
            dataGridView4.Size = new Size(267, 333);
            dataGridView4.TabIndex = 37;
            // 
            // dataGridView5
            // 
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Location = new Point(1293, 174);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.RowHeadersWidth = 51;
            dataGridView5.Size = new Size(243, 333);
            dataGridView5.TabIndex = 38;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label16.Location = new Point(1301, 127);
            label16.Name = "label16";
            label16.Size = new Size(177, 28);
            label16.TabIndex = 40;
            label16.Text = "Eğitmen Maaşları";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label17.Location = new Point(1024, 127);
            label17.Name = "label17";
            label17.Size = new Size(179, 28);
            label17.TabIndex = 39;
            label17.Text = "Personel Maaşları";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label18.Location = new Point(1156, 579);
            label18.Name = "label18";
            label18.Size = new Size(36, 28);
            label18.TabIndex = 44;
            label18.Text = "00";
            // 
            // button7
            // 
            button7.Location = new Point(1038, 579);
            button7.Name = "button7";
            button7.Size = new Size(94, 29);
            button7.TabIndex = 43;
            button7.Text = "Topla";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(1071, 544);
            button8.Name = "button8";
            button8.Size = new Size(94, 29);
            button8.TabIndex = 42;
            button8.Text = "listele";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label19.Location = new Point(1085, 510);
            label19.Name = "label19";
            label19.Size = new Size(69, 28);
            label19.TabIndex = 41;
            label19.Text = "listele";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label20.Location = new Point(1464, 578);
            label20.Name = "label20";
            label20.Size = new Size(36, 28);
            label20.TabIndex = 49;
            label20.Text = "00";
            // 
            // button9
            // 
            button9.Location = new Point(1319, 578);
            button9.Name = "button9";
            button9.Size = new Size(94, 29);
            button9.TabIndex = 48;
            button9.Text = "Topla";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button10
            // 
            button10.Location = new Point(1375, 546);
            button10.Name = "button10";
            button10.Size = new Size(94, 29);
            button10.TabIndex = 47;
            button10.Text = "listele";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label21.Location = new Point(1390, 512);
            label21.Name = "label21";
            label21.Size = new Size(69, 28);
            label21.TabIndex = 46;
            label21.Text = "listele";
            // 
            // button2
            // 
            button2.Location = new Point(750, 798);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 51;
            button2.Text = "Topla";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(859, 800);
            label1.Name = "label1";
            label1.Size = new Size(25, 20);
            label1.TabIndex = 52;
            label1.Text = "00";
            // 
            // button4
            // 
            button4.Location = new Point(36, 25);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 53;
            button4.Text = "GERİ";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // Muhasebe
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1557, 904);
            Controls.Add(button4);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(label20);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(label21);
            Controls.Add(label18);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(label19);
            Controls.Add(label16);
            Controls.Add(label17);
            Controls.Add(dataGridView5);
            Controls.Add(dataGridView4);
            Controls.Add(dateTimePicker3);
            Controls.Add(button6);
            Controls.Add(dateTimePicker2);
            Controls.Add(dataGridView3);
            Controls.Add(label15);
            Controls.Add(button5);
            Controls.Add(dateTimePicker1);
            Controls.Add(label14);
            Controls.Add(textBox2);
            Controls.Add(label13);
            Controls.Add(textBox1);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(comboBox3);
            Controls.Add(label9);
            Controls.Add(button3);
            Controls.Add(button1);
            Controls.Add(label7);
            Controls.Add(dataGridView1);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Name = "Muhasebe";
            Text = "Muhasebe";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private DataGridView dataGridView1;
        private Label label7;
        private Button button1;
        private Button button3;
        private Label label9;
        private ComboBox comboBox3;
        private Label label11;
        private Label label12;
        private TextBox textBox1;
        private Label label13;
        private TextBox textBox2;
        private Label label14;
        private DateTimePicker dateTimePicker1;
        private Button button5;
        private Label label15;
        private DataGridView dataGridView3;
        private DateTimePicker dateTimePicker2;
        private Button button6;
        private DateTimePicker dateTimePicker3;
        private DataGridView dataGridView4;
        private DataGridView dataGridView5;
        private Label label16;
        private Label label17;
        private Label label18;
        private Button button7;
        private Button button8;
        private Label label19;
        private Label label20;
        private Button button9;
        private Button button10;
        private Label label21;
        private Button button2;
        private Label label1;
        private Button button4;
    }
}