﻿namespace FitnessApp2
{
    partial class YoneticiPaneli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YoneticiPaneli));
            groupBox2 = new GroupBox();
            label18 = new Label();
            label17 = new Label();
            textBox15 = new TextBox();
            comboBox2 = new ComboBox();
            label16 = new Label();
            button6 = new Button();
            button5 = new Button();
            label10 = new Label();
            textBox9 = new TextBox();
            label8 = new Label();
            label7 = new Label();
            button4 = new Button();
            label6 = new Label();
            textBox6 = new TextBox();
            comboBox1 = new ComboBox();
            dataGridView1 = new DataGridView();
            label5 = new Label();
            label4 = new Label();
            textBox1 = new TextBox();
            label3 = new Label();
            textBox2 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBox4 = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            textBox3 = new TextBox();
            textBox5 = new TextBox();
            groupBox3 = new GroupBox();
            label19 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label9 = new Label();
            textBox7 = new TextBox();
            dataGridView2 = new DataGridView();
            dataGridView3 = new DataGridView();
            groupBox1 = new GroupBox();
            textBox10 = new TextBox();
            textBox11 = new TextBox();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            textBox12 = new TextBox();
            label11 = new Label();
            label12 = new Label();
            textBox13 = new TextBox();
            label13 = new Label();
            textBox14 = new TextBox();
            label14 = new Label();
            label15 = new Label();
            button7 = new Button();
            button8 = new Button();
            label20 = new Label();
            textBox8 = new TextBox();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label18);
            groupBox2.Controls.Add(label17);
            groupBox2.Controls.Add(textBox15);
            groupBox2.Controls.Add(comboBox2);
            groupBox2.Controls.Add(label16);
            groupBox2.Controls.Add(button6);
            groupBox2.Controls.Add(button5);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(textBox9);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(button4);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(textBox6);
            groupBox2.Controls.Add(comboBox1);
            groupBox2.Location = new Point(467, 185);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(535, 381);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "PAKETLER";
            groupBox2.Enter += groupBox2_Enter;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(362, 126);
            label18.Name = "label18";
            label18.Size = new Size(25, 20);
            label18.TabIndex = 59;
            label18.Text = "00";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(17, 247);
            label17.Name = "label17";
            label17.Size = new Size(54, 20);
            label17.TabIndex = 58;
            label17.Text = "ÖFiyat:";
            // 
            // textBox15
            // 
            textBox15.Location = new Point(17, 125);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(125, 27);
            textBox15.TabIndex = 57;
            textBox15.TextChanged += textBox15_TextChanged;
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "FİTNESS", "PİLATES", "BOKS", "DİYET", "NULL" });
            comboBox2.Location = new Point(17, 216);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(151, 28);
            comboBox2.TabIndex = 56;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(17, 181);
            label16.Name = "label16";
            label16.Size = new Size(73, 20);
            label16.TabIndex = 55;
            label16.Text = "Özel Ders";
            // 
            // button6
            // 
            button6.Location = new Point(198, 338);
            button6.Name = "button6";
            button6.Size = new Size(108, 37);
            button6.TabIndex = 54;
            button6.Text = "GÜNCELLE";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.Location = new Point(312, 338);
            button5.Name = "button5";
            button5.Size = new Size(108, 37);
            button5.TabIndex = 53;
            button5.Text = "SİL";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(17, 101);
            label10.Name = "label10";
            label10.Size = new Size(119, 20);
            label10.TabIndex = 52;
            label10.Text = "Aylık Paket Fiyatı";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(17, 282);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(125, 27);
            textBox9.TabIndex = 51;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(17, 28);
            label8.Name = "label8";
            label8.Size = new Size(65, 20);
            label8.TabIndex = 48;
            label8.Text = "Ay Seçin";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(198, 37);
            label7.Name = "label7";
            label7.Size = new Size(74, 20);
            label7.TabIndex = 47;
            label7.Text = "Paket Adı:";
            // 
            // button4
            // 
            button4.Location = new Point(84, 338);
            button4.Name = "button4";
            button4.Size = new Size(108, 37);
            button4.TabIndex = 45;
            button4.Text = "EKLE";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(198, 127);
            label6.Name = "label6";
            label6.Size = new Size(140, 20);
            label6.TabIndex = 44;
            label6.Text = "Toplam Paket Fiyatı:";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(198, 57);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 43;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12" });
            comboBox1.Location = new Point(17, 57);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 42;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(1008, 572);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(457, 188);
            dataGridView1.TabIndex = 11;
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(11, 123);
            label5.Name = "label5";
            label5.Size = new Size(57, 20);
            label5.TabIndex = 9;
            label5.Text = "Eposta:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(9, 164);
            label4.Name = "label4";
            label4.Size = new Size(73, 20);
            label4.TabIndex = 11;
            label4.Text = "Uzmanlık:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(86, 25);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 27);
            textBox1.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(11, 90);
            label3.Name = "label3";
            label3.Size = new Size(61, 20);
            label3.TabIndex = 10;
            label3.Text = "Telefon:";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(86, 60);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 27);
            textBox2.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(22, 30);
            label1.Name = "label1";
            label1.Size = new Size(31, 20);
            label1.TabIndex = 4;
            label1.Text = "Ad:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 57);
            label2.Name = "label2";
            label2.Size = new Size(53, 20);
            label2.TabIndex = 9;
            label2.Text = "Soyad:";
            // 
            // textBox4
            // 
            textBox4.Location = new Point(86, 126);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 27);
            textBox4.TabIndex = 14;
            // 
            // button1
            // 
            button1.Location = new Point(248, 26);
            button1.Name = "button1";
            button1.Size = new Size(143, 54);
            button1.TabIndex = 0;
            button1.Text = "EKLE";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(248, 86);
            button2.Name = "button2";
            button2.Size = new Size(143, 54);
            button2.TabIndex = 5;
            button2.Text = "SİL";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(248, 147);
            button3.Name = "button3";
            button3.RightToLeft = RightToLeft.Yes;
            button3.Size = new Size(143, 54);
            button3.TabIndex = 6;
            button3.Text = "GÜNCELLE";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(86, 93);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 13;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(86, 157);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 15;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label19);
            groupBox3.Controls.Add(dateTimePicker1);
            groupBox3.Controls.Add(label9);
            groupBox3.Controls.Add(textBox7);
            groupBox3.Controls.Add(textBox5);
            groupBox3.Controls.Add(textBox3);
            groupBox3.Controls.Add(button3);
            groupBox3.Controls.Add(button2);
            groupBox3.Controls.Add(button1);
            groupBox3.Controls.Add(textBox4);
            groupBox3.Controls.Add(label2);
            groupBox3.Controls.Add(label1);
            groupBox3.Controls.Add(textBox2);
            groupBox3.Controls.Add(label3);
            groupBox3.Controls.Add(textBox1);
            groupBox3.Controls.Add(label4);
            groupBox3.Controls.Add(label5);
            groupBox3.Location = new Point(22, 185);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(430, 381);
            groupBox3.TabIndex = 10;
            groupBox3.TabStop = false;
            groupBox3.Text = "EGİTMEN";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(22, 228);
            label19.Name = "label19";
            label19.Size = new Size(99, 20);
            label19.TabIndex = 19;
            label19.Text = "İşe Giriş Tarihi";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(139, 223);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(214, 27);
            dateTimePicker1.TabIndex = 18;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(22, 193);
            label9.Name = "label9";
            label9.Size = new Size(44, 20);
            label9.TabIndex = 17;
            label9.Text = "Maaş";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(86, 190);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(125, 27);
            textBox7.TabIndex = 16;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(22, 572);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.Size = new Size(429, 188);
            dataGridView2.TabIndex = 12;
            dataGridView2.SelectionChanged += dataGridView2_SelectionChanged;
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(467, 572);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.Size = new Size(535, 188);
            dataGridView3.TabIndex = 17;
            dataGridView3.SelectionChanged += dataGridView3_SelectionChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label20);
            groupBox1.Controls.Add(textBox8);
            groupBox1.Controls.Add(textBox10);
            groupBox1.Controls.Add(textBox11);
            groupBox1.Controls.Add(button10);
            groupBox1.Controls.Add(button11);
            groupBox1.Controls.Add(button12);
            groupBox1.Controls.Add(textBox12);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(textBox13);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(textBox14);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(label15);
            groupBox1.Location = new Point(1025, 185);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(430, 381);
            groupBox1.TabIndex = 16;
            groupBox1.TabStop = false;
            groupBox1.Text = "PERSONEL";
            // 
            // textBox10
            // 
            textBox10.Location = new Point(86, 30);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(125, 27);
            textBox10.TabIndex = 15;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(86, 62);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(125, 27);
            textBox11.TabIndex = 13;
            // 
            // button10
            // 
            button10.Location = new Point(248, 147);
            button10.Name = "button10";
            button10.Size = new Size(143, 54);
            button10.TabIndex = 6;
            button10.Text = "GÜNCELLE";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Location = new Point(248, 86);
            button11.Name = "button11";
            button11.Size = new Size(143, 54);
            button11.TabIndex = 5;
            button11.Text = "SİL";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Location = new Point(248, 26);
            button12.Name = "button12";
            button12.Size = new Size(143, 54);
            button12.TabIndex = 0;
            button12.Text = "EKLE";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(86, 90);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(125, 27);
            textBox12.TabIndex = 14;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(15, 60);
            label11.Name = "label11";
            label11.Size = new Size(53, 20);
            label11.TabIndex = 9;
            label11.Text = "Soyad:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(22, 30);
            label12.Name = "label12";
            label12.Size = new Size(31, 20);
            label12.TabIndex = 4;
            label12.Text = "Ad:";
            // 
            // textBox13
            // 
            textBox13.Location = new Point(86, 120);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(125, 27);
            textBox13.TabIndex = 12;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(13, 90);
            label13.Name = "label13";
            label13.Size = new Size(61, 20);
            label13.TabIndex = 10;
            label13.Text = "Telefon:";
            // 
            // textBox14
            // 
            textBox14.Location = new Point(86, 154);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(125, 27);
            textBox14.TabIndex = 9;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(20, 157);
            label14.Name = "label14";
            label14.Size = new Size(48, 20);
            label14.TabIndex = 11;
            label14.Text = "Görev";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(15, 120);
            label15.Name = "label15";
            label15.Size = new Size(57, 20);
            label15.TabIndex = 9;
            label15.Text = "Eposta:";
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(128, 128, 255);
            button7.Font = new Font("Tahoma", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button7.ForeColor = Color.White;
            button7.Location = new Point(242, 27);
            button7.Name = "button7";
            button7.Size = new Size(189, 64);
            button7.TabIndex = 18;
            button7.Text = "GELİR - GİDER DURUMU";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(128, 128, 255);
            button8.Font = new Font("Tahoma", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button8.ForeColor = Color.White;
            button8.Location = new Point(31, 27);
            button8.Name = "button8";
            button8.Size = new Size(189, 64);
            button8.TabIndex = 19;
            button8.Text = "GERİ";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(22, 189);
            label20.Name = "label20";
            label20.Size = new Size(44, 20);
            label20.TabIndex = 19;
            label20.Text = "Maaş";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(86, 186);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(125, 27);
            textBox8.TabIndex = 18;
            // 
            // YoneticiPaneli
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1477, 749);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(dataGridView3);
            Controls.Add(groupBox1);
            Controls.Add(dataGridView2);
            Controls.Add(dataGridView1);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            DoubleBuffered = true;
            Name = "YoneticiPaneli";
            Text = "YoneticiPaneli";
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private GroupBox groupBox2;
        private Label label6;
        private TextBox textBox6;
        private ComboBox comboBox1;
        private Label label8;
        private Label label7;
        private Button button4;
        private Label label10;
        private TextBox textBox9;
        private Button button5;
        private DataGridView dataGridView1;
        private Button button6;
        private Label label5;
        private Label label4;
        private TextBox textBox1;
        private Label label3;
        private TextBox textBox2;
        private Label label1;
        private Label label2;
        private TextBox textBox4;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox textBox3;
        private TextBox textBox5;
        private GroupBox groupBox3;
        private DataGridView dataGridView2;
        private DataGridView dataGridView3;
        private GroupBox groupBox1;
        private TextBox textBox10;
        private TextBox textBox11;
        private Button button10;
        private Button button11;
        private Button button12;
        private TextBox textBox12;
        private Label label11;
        private Label label12;
        private TextBox textBox13;
        private Label label13;
        private TextBox textBox14;
        private Label label14;
        private Label label15;
        private Button button7;
        private Label label16;
        private ComboBox comboBox2;
        private Label label17;
        private TextBox textBox15;
        private Button button8;
        private Label label18;
        private Label label9;
        private TextBox textBox7;
        private Label label19;
        private DateTimePicker dateTimePicker1;
        private Label label20;
        private TextBox textBox8;
    }
}