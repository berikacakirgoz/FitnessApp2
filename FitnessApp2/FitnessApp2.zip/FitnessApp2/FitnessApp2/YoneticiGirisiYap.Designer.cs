﻿namespace FitnessApp2
{
    partial class YoneticiGirisiYap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(YoneticiGirisiYap));
            label2 = new Label();
            textBox1 = new TextBox();
            button1 = new Button();
            rbPersonel = new RadioButton();
            rbYonetici = new RadioButton();
            textBox2 = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label2.ForeColor = Color.White;
            label2.Location = new Point(356, 48);
            label2.Name = "label2";
            label2.Size = new Size(118, 24);
            label2.TabIndex = 9;
            label2.Text = "Kullanıcı Adı";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.ButtonHighlight;
            textBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            textBox1.Location = new Point(500, 42);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(125, 34);
            textBox1.TabIndex = 7;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 222, 89);
            button1.Font = new Font("Showcard Gothic", 10.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.FromArgb(128, 128, 255);
            button1.Location = new Point(419, 179);
            button1.Name = "button1";
            button1.Size = new Size(135, 52);
            button1.TabIndex = 6;
            button1.Text = "Giris Yap";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // rbPersonel
            // 
            rbPersonel.AutoSize = true;
            rbPersonel.Font = new Font("Berlin Sans FB Demi", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            rbPersonel.Location = new Point(501, 263);
            rbPersonel.Name = "rbPersonel";
            rbPersonel.Size = new Size(145, 23);
            rbPersonel.TabIndex = 12;
            rbPersonel.TabStop = true;
            rbPersonel.Text = "Personel Girişi";
            rbPersonel.UseVisualStyleBackColor = true;
            // 
            // rbYonetici
            // 
            rbYonetici.AutoSize = true;
            rbYonetici.Font = new Font("Berlin Sans FB Demi", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            rbYonetici.Location = new Point(355, 263);
            rbYonetici.Name = "rbYonetici";
            rbYonetici.Size = new Size(140, 23);
            rbYonetici.TabIndex = 13;
            rbYonetici.TabStop = true;
            rbYonetici.Text = "Yönetici Girişi";
            rbYonetici.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.ButtonHighlight;
            textBox2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            textBox2.Location = new Point(500, 105);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(125, 34);
            textBox2.TabIndex = 14;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Tahoma", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label1.ForeColor = Color.White;
            label1.Location = new Point(356, 105);
            label1.Name = "label1";
            label1.Size = new Size(50, 24);
            label1.TabIndex = 15;
            label1.Text = "Şifre";
            // 
            // YoneticiGirisiYap
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(128, 128, 255);
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1000, 485);
            Controls.Add(label1);
            Controls.Add(textBox2);
            Controls.Add(rbYonetici);
            Controls.Add(rbPersonel);
            Controls.Add(label2);
            Controls.Add(textBox1);
            Controls.Add(button1);
            Name = "YoneticiGirisiYap";
            Text = "ll";
            Load += YoneticiGirisi_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private TextBox textBox1;
        private Button button1;
        private RadioButton rbPersonel;
        private RadioButton rbYonetici;
        private TextBox textBox2;
        private Label label1;
    }
}